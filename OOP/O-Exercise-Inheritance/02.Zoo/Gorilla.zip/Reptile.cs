﻿
namespace Zoo;

public class Reptile : Animal
{
    public Reptile()
    {
        
    }
}
