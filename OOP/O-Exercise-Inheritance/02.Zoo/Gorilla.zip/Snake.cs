﻿

namespace Zoo;

public class Snake : Reptile
{
    public Snake()
    {
        
    }
}
