﻿
namespace Zoo;

public class Gorilla : Mammal
{
    public Gorilla()
    {
        
    }
}
