﻿

namespace Zoo;

public class Mammal : Animal
{
    public Mammal()
    {
        
    }
}
